package com.example.crm;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    CRM userCRM = new CRM("Hello");
    int choice;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //adding opportunities
        userCRM.addOpporunity(new Accounts(new Lead("Opportunity 1"), createContactList("Jimmy","Jimmy@email.com","123-4567"), new ArrayList<String>(), "Finance"));
        userCRM.addOpporunity(new Accounts(new Lead("Opportunity 2"), createContactList("Timmy","Timmy@email.com","765-4321"), new ArrayList<String>(), "Medical"));
        userCRM.addOpporunity(new Accounts(new Lead("Opportunity 3"), createContactList("Johnny","Johnny@email.com","567-5432"), new ArrayList<String>(), "Medical"));

        //adding Accounts
        userCRM.addAccount(new Accounts(new Lead("Account 1"), createContactList("John","john@email.com","112-2334"), new ArrayList<String>(),"Finance"));
        userCRM.addAccount(new Accounts(new Lead("Account 2"), createContactList("Jeff","jeff@email.com","443-3221"), new ArrayList<String>(),"Medical"));
        userCRM.addAccount(new Accounts(new Lead("Account 3"), createContactList("Jim","jim@email.com","432-7654"), new ArrayList<String>(),"Medical"));

        //update the users invoices
        Button InvoiceView = (Button) findViewById(R.id.invoiceView);
        InvoiceView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in5 = new Intent(MainActivity.this,InvoiceActivity.class);
                in5.putExtra("obj",userCRM);
                startActivity(in5);
            }
        });
        //click to view full table
        Button FullTable = (Button) findViewById(R.id.FullTable);
        FullTable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                choice = 0;
                Intent in = new Intent(MainActivity.this,ViewActivity.class);
                in.putExtra("choice",choice);
                in.putExtra("obj",userCRM);

                startActivity(in);
            }
        });

        //Button to view the users accounts by its Category
        Button ViewCategory = (Button) findViewById(R.id.ViewCategory);
        ViewCategory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                choice = 1;
                Intent in2 = new Intent(MainActivity.this,ViewActivity.class);
                in2.putExtra("choice",choice);
                in2.putExtra("obj",userCRM);
                startActivity(in2);
            }
        });
        //view accounts and opportunities by date created
        Button ViewbyDate = (Button) findViewById(R.id.viewbyDate);
        ViewbyDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                choice = 2;
                Intent in3 = new Intent(MainActivity.this,ViewActivity.class);
                in3.putExtra("choice",choice);
                in3.putExtra("obj",userCRM);
                startActivity(in3);
            }
        });
        //view invoices of all accounts purchase history
        Button ViewQty = (Button) findViewById(R.id.ViewQty);
        ViewQty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                choice = 3;
                Intent in4 = new Intent(MainActivity.this,ViewActivity.class);
                in4.putExtra("choice",choice);
                in4.putExtra("obj",userCRM);
                startActivity(in4);
            }
        });

    }
    public static ArrayList<Contacts> createContactList(String name, String email,String phonenum)
    {
        ArrayList<Contacts> ContactsList = new ArrayList<>();
        Contacts contact = new Contacts(name,phonenum,email);
        ContactsList.add(contact);

        return ContactsList;
    }


}
