package com.example.crm_v3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class ViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);

        TextView textview = (TextView) findViewById(R.id.textView);

        int choice =(int) getIntent().getSerializableExtra("choice");

        if ((getIntent().getSerializableExtra("obj")) != null) {
            CRM user2CRM = (CRM) getIntent().getSerializableExtra("obj");
            if(choice == 0) {
                textview.setText(user2CRM.allInfo());
            }
            else if(choice == 1)
            {
                textview.setText(user2CRM.printFinance() + user2CRM.printMedical());
            }
            else if(choice == 2)
            {
                textview.setText(user2CRM.listAccountDates() + user2CRM.listOpportunityDates());
            }
            else if(choice == 3)
            {
                textview.setText(user2CRM.listAccountQtyPurchased());
            }
        }


    }
}
