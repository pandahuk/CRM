package com.example.crm_v3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class InvoiceActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invoice);

        final TextView textview = (TextView) findViewById(R.id.invoiceView);

        if ((getIntent().getSerializableExtra("obj")) != null) {
            final CRM user2CRM = (CRM) getIntent().getSerializableExtra("obj");
            textview.setText("Here are your purchase invoices. Which one would you like to update:\n" + user2CRM.listAccountQtyPurchased());
            Button addInvoice = (Button) findViewById(R.id.addInvoice);
            addInvoice.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    EditText posInput = (EditText) findViewById(R.id.posInput);
                    EditText invoiceInput = (EditText) findViewById(R.id.invoiceInput);

                    int position = Integer.parseInt(posInput.getText().toString());
                    int amount = Integer.parseInt(invoiceInput.getText().toString());
                    user2CRM.updateQty(position,amount);
                    textview.setText("Here are your purchase invoices. Which one would you like to update:\n" + user2CRM.listAccountQtyPurchased());

                }
            });
        }
    }
}
